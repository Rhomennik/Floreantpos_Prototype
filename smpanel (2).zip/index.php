<?php
include("config.php");
ob_start();
session_start();

if (!isset($_SESSION["login"])) {
    header("Location: login.php");
}

$sorgu = $conn->query('SELECT count FROM mithat_players WHERE id=1');
$sorgu1 = $conn->query('SELECT tr FROM mithat_players WHERE id=1');
$sorgu2 = $conn->query('SELECT ct FROM mithat_players WHERE id=1');

$sorguservername = $conn->query('SELECT servername FROM mithat_server WHERE id=1');
$sorguip = $conn->query('SELECT serverip FROM mithat_server WHERE id=1');
$sorguport = $conn->query('SELECT serverport FROM mithat_server WHERE id=1');

$sorgumap = $conn->query('SELECT name FROM mithat_map WHERE id=1');

$sorguscorect = $conn->query('SELECT ctscore FROM mithat_score WHERE id=1');
$sorguscoret = $conn->query('SELECT tscore FROM mithat_score WHERE id=1');

$sorgulastname = $conn->query('SELECT name FROM mithat_lastconnected WHERE id=1');
$sorgulaststeamid = $conn->query('SELECT steamid FROM mithat_lastconnected WHERE id=1');
$sorgulastip = $conn->query('SELECT ip FROM mithat_lastconnected WHERE id=1');
$sorgulasttime = $conn->query('SELECT time FROM mithat_lastconnected WHERE id=1');


$data = $sorgu->fetch_assoc();
$datatr = $sorgu1->fetch_assoc();
$datact = $sorgu2->fetch_assoc();
$datasvn = $sorguservername->fetch_assoc();
$dataip = $sorguip->fetch_assoc();
$dataport = $sorguport->fetch_assoc();
$datamap = $sorgumap->fetch_assoc();
$datascorect = $sorguscorect->fetch_assoc();
$datascoret = $sorguscoret->fetch_assoc();

$datalastname = $sorgulastname->fetch_assoc();
$datalaststeamid = $sorgulaststeamid->fetch_assoc();
$datalastip = $sorgulastip->fetch_assoc();
$datalasttime = $sorgulasttime->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- This file has been downloaded froma Bootsnipp.com. Enjoy! -->
    <title>Sourcemod Admin Paneli | Mithat Guner</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet" media="screen">
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top topbar">
    <div class="container-fluid">

        <div class="navbar-header">

            <a href="#" class="navbar-brand">
                <span class="visible-xs">PL</span>
                <span class="hidden-xs">SMPanel</span>
            </a>

            <p class="navbar-text">
                <a href="#" class="sidebar-toggle">
                    <i class="fa fa-bars"></i>
                </a>
            </p>

        </div>

        <div class="navbar-collapse collapse" id="navbar-collapse-main">

            <ul class="nav navbar-nav navbar-right">

                <li>
                </li>

                <li class="dropdown">
                    <button class="navbar-btn" data-toggle="dropdown">
                        <span class="glyphicon glyphicon-play-circle"></span>
                    </button>
                    <ul class="dropdown-menu">
                        <li class="nav-divider"></li>
                        <li><a href="logout.php">LOGOUT</a></li>
                    </ul>
                </li>

            </ul>

        </div>
    </div>
</nav>

<article class="wrapper">

    <aside class="sidebar">
        <ul class="sidebar-nav">
            <li class="active"><a href="#dashboard" data-toggle="tab"><i class="fa fa-dashboard"></i> <span>Panel</span></a>
            </li>
            <li><a href="#configuration" data-toggle="tab"><i class="fa fa-cogs"></i> <span>Settings</span></a></li>
            <li><a href="#users" data-toggle="tab"><i class="fa fa-users"></i> <span>Users</span></a></li>
            <li><a href="#mail" data-toggle="tab"><i class="fa fa-envelope"></i> <span>Mail</span></a></li>
        </ul>
    </aside>

    <section class="main">

        <section class="tab-content">

            <section class="tab-pane active fade in content" id="dashboard">

                <div class="row">

                    <div class="col-xs-6 col-sm-3">

                        <div class="offer offer-info">
                            <div class="shape">
                                <div class="shape-text">
                                    SV
                                </div>
                            </div>
                            <div class="offer-content">
                                <h3 class="lead">
                                    <?= $datasvn['servername'] ?>
                                </h3>
                                <p>
                                    <?= $dataip['serverip'] ?> : <?= $dataport['serverport'] ?>
                                </p>
                            </div>
                        </div>

                    </div>

                    <div class="col-xs-6 col-sm-3">

                        <div class="offer offer-info">
                            <div class="shape">
                                <div class="shape-text">
                                    MAP
                                </div>
                            </div>
                            <div class="offer-content">
                                <h3 class="lead">
                                    CURRENT MAP
                                </h3>
                                <p>
                                    <?= $datamap['name'] ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xs-6 col-sm-3">

                        <div class="offer offer-radius offer-danger">
                            <div class="shape">
                                <div class="shape-text">
                                    SV
                                </div>
                            </div>
                            <div class="offer-content">
                                <h3 class="lead">
                                    T SCORE
                                </h3>
                                <p>
                                <h3><?= $datascoret['tscore'] ?></h3>
                                </p>
                            </div>
                        </div>

                    </div>

                    <div class="col-xs-6 col-sm-3">

                        <div class="offer offer-radius offer-primary">
                            <div class="shape">
                                <div class="shape-text">
                                    SV
                                </div>
                            </div>
                            <div class="offer-content">
                                <h3 class="lead">
                                    CT SCORE
                                </h3>
                                <p>
                                <h3><?= $datascorect['ctscore'] ?></h3>
                                </p>
                            </div>
                        </div>

                    </div>

                    <div class="col-xs-9 col-sm-9">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Server Stat
                            </div>
                            <div class="panel-body">


                                <div class="col col-md-12">
                                    <div class="row">
                                        <div class="col col-md-22">
                                            <h4>Server Stat:</h4>
                                            All Users<span class="pull-right strong"><?= $data['count'] ?></span>
                                            <div class="progress">
                                                <div class="progress-bar progress-bar-success" role="progressbar"
                                                     aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"
                                                     style="width:<?= $data['count'] ?>%"><?= $data['count'] ?>%
                                                </div>
                                            </div>

                                            T Users<span class="pull-right strong"><?= $datatr['tr'] ?></span>
                                            <div class="progress">
                                                <div class="progress-bar progress-bar-danger" role="progressbar"
                                                     aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"
                                                     style="width:<?= $datatr['tr'] ?>%"><?= $datatr['tr'] ?>%
                                                </div>
                                            </div>

                                            CT Users<span class="pull-right strong"><?= $datact['ct'] ?></span>
                                            <div class="progress">
                                                <div class="progress-bar progress-bar-succes" role="progressbar"
                                                     aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"
                                                     style="width:<?= $datact['ct'] ?>%"><?= $datact['ct'] ?>%
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-3">
                        <div class="offer offer-warning">
                            <div class="shape">
                            </div>
                            <div class="offer-content">
                                <h3 class="lead">
                                    Last Connected
                                </h3>
                                <p>
                                    <strong>Name:</strong> <?= $datalastname['name'] ?></br>
                                    <strong>SteamID: </strong><?= $datalaststeamid['steamid'] ?></br>
                                    <strong>IP: </strong><?= $datalastip['ip'] ?></br>
                                    <strong>Time:</strong> <?= $datalasttime['time'] ?>
                                </p>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Mithat Güner
                            </div>
                            <div class="panel-body">
                                Sourcemod CSGO Server Tracker
                            </div>
                        </div>
                    </div>

                </div>

            </section>

            <section class="tab-pane fade" id="configuration">
                <nav class="subbar">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#access" data-toggle="tab"><i class="fa fa-code"></i>
                                <span>example</span></a></li>
                        <li><a href="#roles" data-toggle="tab"><i class="fa fa-user"></i> <span>example</span></a></li>
                    </ul>
                </nav>

                <section class="tab-content content">

                    <section class="tab-pane active fade in" id="access">

                        <div class="row">
                            <div class="col-md-3 col-sm-4">
                                <div class="wrimagecard wrimagecard-topimage">
                                    <a href="ftp1/index.php">
                                        <div class="wrimagecard-topimage_header"
                                             style="background-color: rgba(22, 160, 133, 0.1)">
                                            <center><i class="fa fa-cubes" style="color:#16A085"></i></center>
                                        </div>
                                        <div class="wrimagecard-topimage_title">
                                            <h4>WebFTP
                                                <div class="pull-right badge" id="WrControls"></div>
                                            </h4>
                                        </div>
                                    </a>
                                </div>
                            </div>

                            <div class="col-md-3 col-sm-4">
                                <div class="wrimagecard wrimagecard-topimage">
                                    <a href="ftp/index.php">
                                        <div class="wrimagecard-topimage_header"
                                             style="background-color: rgba(22, 160, 133, 0.1)">
                                            <center><i class="fa fa-cubes" style="color:#16A085"></i></center>
                                        </div>
                                        <div class="wrimagecard-topimage_title">
                                            <h4>WebFTP
                                                <div class="pull-right badge" id="WrControls"></div>
                                            </h4>
                                        </div>
                                    </a>
                                </div>
                            </div>

                            <div class="col-md-3 col-sm-4">
                                <div class="wrimagecard wrimagecard-topimage">
                                    <a href="rcon.php">
                                        <div class="wrimagecard-topimage_header"
                                             style="background-color: rgba(22, 160, 133, 0.1)">
                                            <center><i class="fa fa-cubes" style="color:#16A085"></i></center>
                                        </div>
                                        <div class="wrimagecard-topimage_title">
                                            <h4>RCON
                                                <div class="pull-right badge" id="WrControls"></div>
                                            </h4>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        example
                                    </div>
                                    <div class="panel-body">
                                        <br/><br/><br/><br/>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </section>

                    <section class="tab-pane fade" id="roles">

                        <div class="row">
                            <div class="col-xs-12 col-sm-8 col-md-9">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        example
                                    </div>
                                    <div class="panel-body">
                                        <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
                                    </div>
                                </div>
                            </div>

                            <div class="hidden-xs col-sm-4 col-md-3">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        example
                                    </div>
                                    <div class="panel-body">
                                        <br/><br/><br/>
                                    </div>
                                </div>

                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        example
                                    </div>
                                    <div class="panel-body">
                                        <br/><br/><br/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                </section>

            </section>

            <section class="tab-pane fade" id="users">
                <div class="container">
                    <div class="jumbotron">
                        <h1>Online Users</h1>

                        <table class="table table-hover table-inverse">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>SteamID</th>
                                <th>IP</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $bul = $conn->query("SELECT * FROM mithat_playerstats");
                            while ($gos = $bul->fetch_array()) {
                                ?>
                                <tr>
                                    <td><?= $gos["name"] ?></td>
                                    <td><?= $gos["steamid"] ?></td>
                                    <td><?= $gos["ip"] ?></td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>


                    </div>


                </div>


            </section>

            <section class="tab-pane fade" id="mail">
                <div class="chatContainer">

                    <div class="chatTitleContainer">Comments</div>
                    <div class="chatHistoryContainer">

                        <ul class="formComments">
                            <?php
                            $bul = $conn->query("SELECT * FROM mithat_reports");
                            while ($gos = $bul->fetch_array()) {
                                ?>
                                <li class="commentLi commentstep-1" data-commentid="4">
                                    <table class="form-comments-table">
                                        <tr>
                                            <td>
                                                <div class="comment-timestamp"><?= $gos["steamid"] ?></div>
                                            </td>
                                            <td>
                                                <div class="comment-user"><?= $gos["name"] ?></div>
                                            </td>
                                            <td>
                                                <div class="comment-avatar">
                                                    <img src="http://www.liveside.net/wp-content/images/2013/03/Mail.png">
                                                </div>
                                            </td>
                                            <td>
                                                <div id="comment-4" data-commentid="4" class="comment comment-step1">
                                                    <?= $gos["report"] ?>
                                                    <div id="commentactions-4" class="comment-actions">
                                                        <div class="btn-group" role="group" aria-label="...">
                                                            <button type="button" class="btn btn-primary btn-sm"><i
                                                                        class="fa fa-edit"></i> Reply
                                                            </button>
                                                            <button type="button" class="btn btn-default btn-sm"><i
                                                                        class="fa fa-pencil"></i> Edit
                                                            </button>
                                                            <button type="button" class="btn btn-danger btn-sm"><i
                                                                        class="fa fa-trash"></i>Delete
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </section>
        </section>
    </section>
</article>


<script type="text/javascript">

    $(document).on("click", ".sidebar-toggle", function () {
        $(".wrapper").toggleClass("toggled");
    });
</script>
</body>
</html>

<?php
    $conn->close();
?>