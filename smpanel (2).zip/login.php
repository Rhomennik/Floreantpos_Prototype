<?php
    session_start();

    // Is the user already logged in?
    if(isset($_SESSION['login']) && $_SESSION['login'] == "true"){
        header("Location: index.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- This file has been downloaded from Bootsnipp.com. Enjoy! -->
    <title>SMPanel - Login</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/login.css" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
</head>
<body>
<form action="dologin.php" method="POST">
<div class="container">
	<div id="login-box">
		<div class="logo">
			<img src="https://vignette3.wikia.nocookie.net/logopedia/images/c/c8/CSGO.png/revision/latest?cb=20150828062634" class="img img-responsive img-circle center-block"/>
			<h1 class="logo-caption"><span class="tweak">S</span>ource<span class="tweak">M</span>od</h1>
			<h1 class="logo-caption"><span class="tweak">M</span>ithat<span class="tweak"> G</span>uner</h1>
		</div><!-- /.logo -->
		<div class="controls">
			<input type="text" name="kadi" placeholder="Username" class="form-control" />
			<input type="text" name="sifre" placeholder="Password" class="form-control" />
			<button type="submit" class="btn btn-default btn-block btn-custom">Login</button>
		</div><!-- /.controls -->
	</div><!-- /#login-box -->
</div><!-- /.container -->
</form>

<?php if(isset($_SESSION['empty'])){ ?>
    <?php if($_SESSION['empty'] == "wrong"){ ?>
    <div class="container">
        <div class="row" >
            <div class="popupunder alert alert-wrong fade in" ><button type = "button" class="close close-sm" data - dismiss = "alert" ><i class="glyphicon glyphicon-remove" ></i ></button ><strong > Error :</strong > Wrong username or password .</div >
        </div >
    </div>

<?php
    } // Second/Nested IF
}else // First IF's else
    session_destroy();
?>

<div id="particles-js"></div>
<!--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>-->
<script type="text/javascript">
$.getScript("https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js", function(){
    particlesJS('particles-js',
      {
        "particles": {
          "number": {
            "value": 80,
            "density": {
              "enable": true,
              "value_area": 800
            }
          },
          "color": {
            "value": "#ffffff"
          },
          "shape": {
            "type": "circle",
            "stroke": {
              "width": 0,
              "color": "#000000"
            },
            "polygon": {
              "nb_sides": 5
            },
            "image": {
              "width": 100,
              "height": 100
            }
          },
          "opacity": {
            "value": 0.5,
            "random": false,
            "anim": {
              "enable": false,
              "speed": 1,
              "opacity_min": 0.1,
              "sync": false
            }
          },
          "size": {
            "value": 5,
            "random": true,
            "anim": {
              "enable": false,
              "speed": 40,
              "size_min": 0.1,
              "sync": false
            }
          },
          "line_linked": {
            "enable": true,
            "distance": 150,
            "color": "#ffffff",
            "opacity": 0.4,
            "width": 1
          },
          "move": {
            "enable": true,
            "speed": 6,
            "direction": "none",
            "random": false,
            "straight": false,
            "out_mode": "out",
            "attract": {
              "enable": false,
              "rotateX": 600,
              "rotateY": 1200
            }
          }
        },
        "interactivity": {
          "detect_on": "canvas",
          "events": {
            "onhover": {
              "enable": true,
              "mode": "repulse"
            },
            "onclick": {
              "enable": true,
              "mode": "push"
            },
            "resize": true
          },
          "modes": {
            "grab": {
              "distance": 400,
              "line_linked": {
                "opacity": 1
              }
            },
            "bubble": {
              "distance": 400,
              "size": 40,
              "duration": 2,
              "opacity": 8,
              "speed": 3
            },
            "repulse": {
              "distance": 200
            },
            "push": {
              "particles_nb": 4
            },
            "remove": {
              "particles_nb": 2
            }
          }
        },
        "retina_detect": true,
        "config_demo": {
          "hide_card": false,
          "background_color": "#b61924",
          "background_image": "",
          "background_position": "50% 50%",
          "background_repeat": "no-repeat",
          "background_size": "cover"
        }
      }
    );

});

$('.popovers').popover();
window.setTimeout(function () {
    $(".alert").fadeTo(2000, 500).slideUp(500, function () {
        $(this).remove();
    });
// 500 : Time will remain on the screen
}, 500);

</script>
</body>
</html>
