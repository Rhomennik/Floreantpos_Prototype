<?php
	// German translation by : Günther Leitgeb

	// Change permissions
	$lblOwner="Besitzer";
	$lblGroup="Gruppe";
	$lblPublic="&Ouml;ffentlich";
	$lblRead="Lesen";
	$lblWrite="Schr.";
	$lblExecute="Ausf.";

	//Front End

    $lblFileSizeTooBig = "Die Datei ist zu groß";
	$lblAnonymousAccess = "Anonymer Zugriff";
	$lblASCIIMode = "ASCII";
	$lblBinaryMode = "Bin&auml;�r";
	$lblChangeMode = "Wechsel Bin&auml;r/ASCII";
	$lblSetPermissions	= "Zugriffsrechte &Auml;ndern";
	$lblConnectToFTPServer = "Verbinde zu FTP Server";
	$lblConnectedTo = "Verbinde zu";
	$lblCouldNotChangePermissionsFor = "Zugriffsrechte konnten nicht ge&auml;ndert werden f&uuml;r";
	$lblCouldNotConnectToServer = "Verbindung mit Server fehlgeschlagen";
	$lblCouldNotCreate = "Erstellen fehlgeschlagen";
	$lblCouldNotDelete = "L&ouml;schen fehlgeschlagen";
	$lblCouldNotRename = "Umbenennen fehlgeschlagen";
	$lblCouldNotUnzip ="Unzip fehlgeschlagen";
	$lblCreated = "Erstellt";
	$lblCreateDirectory	= "Verzeichnis erstellen";
	$lblCurrentDirectory="Aktuelles Verzeichnis";
	$lblCurrentMode = "Aktueller Modus";
	$lblDate	= "Datum";
	$lblEditFile = "Edit";
	$lblDelete	= "L&ouml;schen";
	$lblDeleted = "Gel&ouml;scht";
	$lblDeleteFile	= "Datei l&ouml;schen";
	$lblDetails = "Details";
	$lblDirectory = "Verzeichnis";
	$lblDirectoryEmpty = "Verzeichnis ist leer";
	$lblDisclaimer = "Bei WebFTP existiert ABSOLUT KEINE GARANTIE. Dies ist eine Freeware Software und Sie k&ouml;nnen sie, unter Beachtung bestimmter Bedingungen, ohne weiteres ver&auml;ndern. Lesen Sie die komplette GPL Lizenz <A HREF='gpl.txt' style='font-size:7pt;'>hier</A>";
	$lblErrorDownloadingFile = "Download der Datei fehlgeschlagen";
	$lblFileCouldNotBeUploaded = "Datei konnte nicht hochgeladewn werden";
	$lblFilePermissionChanged="Dateizugriffsrechte ge&auml;ndert";
	$lblCouldNotChangePermissions="Zugriffsrechte konnten nicht ge&auml;ndert werden";
	$lblFileTasks = "Datei und Verzeichnis Optionen";
	$lblGoToDirectory = "Wechsel zum Verzeichnis";
	$lblIndexOf="Inhalt von";
	$lblLogIn ="Einloggen";
	$lblLogOff ="Ausloggen";
	$lblName = "Name";
	$lblNewName = "Nuer Name";
	$lblNotConnected = "Nicht verbunden";
	$lblNotice = "Nachricht";
	$lblPassword = "Passwort";
	$lblLanguage= "Sprache";
	$lblPermissions = "Zugriffsrechte";
	$lblPort = "Port";
	$lblRename	= "Umbenennen";
	$lblRenamedTo = "Umbenennen zu";
	$lblRetry = "Wiederholen";
	$lblServer = "Server";
	$lblSize = "Gr&ouml;sse";
	$lblFileType = "Dateityp";
	$lblTo = "zu";
	$lblTransferMode = "Transfer Mode";
	$lblTryAgain = "Noch einmal versuchen...";
	$lblUnziped = "Unzip erfolgreich";
	$lblUp = "Zur&uuml;ck";
	$lblUploadFile	= "Datei hochladen";
	$lblUser = "User";
	$lblVersion ="Version";
	$lblWithUser = "mit Benutzer";
	$lblUnZipFile = "Unzip File";
	$lblZipFile = "Zip File";
	$lblPasive = "Passive";
	?>
