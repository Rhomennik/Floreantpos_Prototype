<?php
// English translation by : azalio

// Change permissions
$lblOwner="Тырфхыхі";
$lblGroup="У№ѓяяр";
$lblPublic="Яѓсышїэћщ";
$lblRead="зђхэшх";
$lblWrite="Чряшёќ";
$lblExecute="Тћяюыэхэшх.";

//Front End

    $lblFileSizeTooBig = "арчьх№ єрщыр ёышјъюь сюыќјющ";
$lblAnonymousAccess = "Рэюэшьэћщ фюёђѓя";
$lblASCIIMode = "ASCII";
$lblBinaryMode = "Binary";
$lblChangeMode = "Ях№хъыўїшђќ Binary/ASCII";
$lblSetPermissions = "Яюьхэџђќ я№ртр фюёђѓяр";
$lblConnectToFTPServer = "бюхфшэшђќёџ ё FTP-ёх№тх№юь";
$lblConnectedTo = "Яюъыўїхэ ъ";
$lblCouldNotChangePermissionsFor = "Эх ьюуѓ яюьхэџђќ я№ртр фыџ";
$lblCouldNotConnectToServer = "Эх ьюуѓ яюфъыўїшђќёџ ъ ёх№тх№ѓ";
$lblCouldNotCreate = "Эх ьюуѓ ёючфрђќ";
$lblCouldNotDelete = "Эх ьюуѓ ѓфрышђќ";
$lblCouldNotRename = "Эх ьюуѓ ях№хшьхэютрђќ";
$lblCouldNotUnzip ="Эх ьюуѓ №рчр№ѕштш№ютрђќ";
$lblCreated = "ёючфрэю";
$lblCreateDirectory = "бючфрэшх фш№хъђю№шш";
$lblCurrentDirectory="вхъѓљрџ фш№хъђю№шџ";
$lblCurrentMode = "вхъѓљшщ №хцшь";
$lblDate = "Фрђр";
$lblEditFile = "Edit";
$lblDelete = "гфрышђќ";
$lblDeleted = "гфрыхэю";
$lblDeleteFile = "гфрышђќ єрщы";
$lblDetails = "Яюф№юсэю";
$lblDirectory = "Фш№хъђю№шџ";
$lblDirectoryEmpty = "Фш№хъђю№шџ яѓёђр";
$lblDisclaimer = "phpWebFTP comes with ABSOLUTELY NO WARRANTY. This is free software, and you are welcome to redistribute it under certain conditions. Read the full GPL license <A HREF='gpl.txt' style='font-size:7pt;'>here</A>";
$lblErrorDownloadingFile = "Юјшсър я№ш чру№ѓчъх єрщыр";
$lblFileCouldNotBeUploaded = "дрщы эх ьюцхђ сћђќ чру№ѓцхэ";
$lblFilePermissionChanged="Я№ртр фюёђѓяр ъ єрщыѓ шчьхэхэћ";
$lblCouldNotChangePermissions ="Я№ртр фюёђѓяр ъ єрщыѓ эх ьюуѓђ сћђќ шчьхэхэћ";
$lblFileTasks = "Чрфрэшџ фыџ єрщыют ш яряюъ";
$lblGoToDirectory = "Ях№хщђш т фш№хъђю№шў";
$lblIndexOf = "бяшёюъ";
$lblLogIn ="Тющђш";
$lblLogOff ="Тћщђш";
$lblName = "Шьџ";
$lblNewName = "Эютюх шьџ";
$lblNotConnected = "Эх яюфъыўїхэ";
$lblNotice = "гтхфюьыхэшх";
$lblPassword = "Яр№юыќ";
$lblLanguage= "пчћъ";
$lblPermissions = "Я№ртр фюёђѓяр";
$lblPort = "Яю№ђ";
$lblRename = "Ях№хшьхэютрђќ";
$lblRenamedTo = "ях№хшьхэютрђќ ";
$lblRetry = "Яютђю№";
$lblServer = "бх№тх№";
$lblSize = "арчьх№";
$lblFileType = "вшя";
$lblTo = "т";
$lblTransferMode = "Ьхђюф ях№хфрїш";
$lblTryAgain = "Яюя№юсѓщђх ёэютр...";
$lblUnziped = "№рёяръютрээю";
$lblUp = "Ттх№ѕ";
$lblUploadFile = "Чру№ѓчър єрщыр";
$lblUser = "Яюыќчютрђхыќ";
$lblVersion ="Тх№ёшџ";
$lblWithUser = "ё яюыќчютрђхыхь";
$lblUnZipFile = "арёяръютрээћщ єрщы";
$lblZipFile = "Чряръютрээћщ єрщы";
$lblPasive = "Ярёёштэћщ";
?>
