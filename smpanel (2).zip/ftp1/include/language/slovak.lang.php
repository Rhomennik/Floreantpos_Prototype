<?php
	// Slovak translation by : Tom� Hled�k - www.arplus.sk
	// Date of creation      : 27.02.2005
	// Revision for 3.2:	 : 15.04.2006
	// Used charset		 : cp1250

	// Change permissions
	$lblOwner="Majite�";
	$lblGroup="Skupina";
	$lblPublic="Ostatn�";
	$lblRead="��tanie";
	$lblWrite="Z�pis";
	$lblExecute="Sp���.";

	//Front End

    $lblFileSizeTooBig = "S�bor je pr�li� ve�k�";
	$lblAnonymousAccess = "Anonymn� pr�stup";
	$lblASCIIMode = "ASCII";
	$lblBinaryMode = "bin�rny";
	$lblChangeMode = "Zmena m�du bin�rny/ASCII";
	$lblSetPermissions	= "Zmeni� pr�va";
	$lblConnectToFTPServer = "Prihl�ste sa k FTP serveru";
	$lblConnectedTo = "Pripojen� k";
	$lblCouldNotChangePermissionsFor = "Nem��em zmeni� pr�va pre";
	$lblCouldNotConnectToServer = "Nem��em sa pripoji� k serveru";
	$lblCouldNotCreate = "Nem��em vytvori�";
	$lblCouldNotDelete = "Nem��em zmaza�";
	$lblCouldNotRename = "Nem��em premenova�";
	$lblCouldNotUnzip ="Nem��em dekomprimova�";
	$lblCreated = "vytvoren�";
	$lblCreateDirectory	= "Vytvori� adres�r";
	$lblCurrentDirectory="Aktu�lny adres�r";
	$lblCurrentMode = "Aktu�lny m�d";
	$lblDate	= "D�tum";
	$lblDelete	= "Zmaza�";
	$lblEditFile = "Upravi�";
	$lblDeleted = "zmazan�";
	$lblDeleteFile	= "Zmaza�";
	$lblDetails = "Podrobnosti";
	$lblDirectory = "Adres�r";
	$lblDirectoryEmpty = "Adres�r je pr�zdny";
	$lblDisclaimer = "phpWebFTP je vyroben� BEZ AKEJKO�VEK Z�RUKY. Toto je vo�ne ��rite�n� software. Budeme radi, ak ho budete ��ri� za nezmenen�ch podmienok. Pre��tajte si plne znenie GPL licencie <A HREF='gpl.txt' style='font-size:7pt;'>tu.</A>";
	$lblErrorDownloadingFile = "Chyba pri s�ahovan� s�boru";
	$lblFileCouldNotBeUploaded = "S�bor nem��e by� nahrat�";
	$lblFilePermissionChanged="S�borov� pr�va boli zmenen�";
	$lblCouldNotChangePermissions ="S�borov� pr�va nemohli by� zmenen�";
	$lblFileTasks = "Pr�ca so syst�mom";
	$lblGoToDirectory = "Prejs� do adres�ra";
	$lblIndexOf = "Zoznam";
	$lblLogIn ="Prihl�si� sa";
	$lblLogOff ="Odhl�si� sa";
	$lblName = "N�zov";
	$lblNewName = "Nov� n�zov";
	$lblNotConnected = "Nepripojen�";
	$lblNotice = "Ozn�menie";
	$lblPassword = "Heslo";
	$lblLanguage= "Jazyk";
	$lblPermissions = "Pr�va";
	$lblPort = "Port";
	$lblRename	= "Premenova�";
	$lblRenamedTo = "premenovan� na";
	$lblRetry = "Sk�si� znovu";
	$lblServer = "Server";
	$lblSize = "Ve�kos�";
	$lblFileType = "Typ";
	$lblTo = "na";
	$lblTransferMode = "M�d prenosu d�t";
	$lblTryAgain = "Sk�ste to znovu ...";
	$lblUnziped = "dekomprimovan�";
	$lblUp = "O �rove� vy��ie";
	$lblUploadFile	= "Nahra� s�bor";
	$lblUser = "U��vate�";
	$lblVersion ="verzia";
	$lblWithUser = "s u��vate�om";
	$lblUnZipFile = "Dekomprimova� s�bor";
	$lblZipFile = "Komprimova� soubor";
	$lblPasive = "Pas�vny";
?>