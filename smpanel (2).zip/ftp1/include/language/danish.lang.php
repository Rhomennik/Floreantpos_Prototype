<?php
        // Danish Translation By : Michael Andreassen

        // Change permissions
        $lblOwner="Ejer";
        $lblGroup="Gruppe";
        $lblPublic="Offentlig";
        $lblRead="Læs";
        $lblWrite="Skriv";
        $lblExecute="Udfør";

        //Front End

    $lblFileSizeTooBig = "Filstørrelsen Er For Stor";
        $lblAnonymousAccess = "Anonym Adgang";
        $lblASCIIMode = "ASCII";
        $lblBinaryMode = "Binær";
        $lblChangeMode = "Skift Ml. Binær/ASCII";
        $lblSetPermissions        = "Skift Rettigheder";
        $lblConnectToFTPServer = "Forbind Til FTP Server";
        $lblConnectedTo = "Forbundet Til";
        $lblCouldNotChangePermissionsFor = "Kunne Ikke Skifte Rettigheder For";
        $lblCouldNotConnectToServer = "Kunne Ikke Forbinde Til Server";
        $lblCouldNotCreate = "Kunne Ikke Oprette";
        $lblCouldNotDelete = "Kunne Ikke Slette";
        $lblCouldNotRename = "Kunne Ikke Omdøbe";
        $lblCouldNotUnzip ="Kunne Ikke Unzippe";
        $lblCreated = "oprettet";
        $lblCreateDirectory        = "Opret Mappe";
        $lblCurrentDirectory="Nuv. Mappe";
        $lblCurrentMode = "Nuv. Modus";
        $lblDate        = "Dato";
		$lblEditFile = "Edit";
        $lblDelete        = "Slet";
        $lblDeleted = "slettet";
        $lblDeleteFile        = "Slet Fil";
        $lblDetails = "Detaljer";
        $lblDirectory = "Mappe";
        $lblDirectoryEmpty = "Mappen Er Tom";
        $lblDisclaimer = "phpWebFTP Kommer UDEN NOGEN GARANTIER. Dette Er Gratis Software, Og Du Er Velkommen Til At Redistribuere Det Under Bestemte Betingelser. Læs Den Fulde GPL Licens <A HREF='gpl.txt' style='font-size:7pt;'>HER</A>";
        $lblErrorDownloadingFile = "Fejl Ved Download Af Fil";
        $lblFileCouldNotBeUploaded = "Filen Kunne Ikke Uploades";
        $lblFilePermissionChanged="Filtilladelser Ændret";
        $lblCouldNotChangePermissions ="Filtilladelser Kunne Ikke Ændres";
        $lblFileTasks = "Fil Og Folder Opgaver";
        $lblGoToDirectory = "Gå Til Mappe";
        $lblIndexOf = "Indeks Af";
        $lblLogIn ="Log Ind";
        $lblLogOff ="Log Ud";
        $lblName = "Navn";
        $lblNewName = "Nyt Navn";
        $lblNotConnected = "Ikke Forbundet";
        $lblNotice = "Bemærk";
        $lblPassword = "Kodeord";
        $lblLanguage= "Sprog";
        $lblPermissions = "Tilladelser";
        $lblPort = "Port";
        $lblRename        = "Omdøb";
        $lblRenamedTo = "omdøbt Til";
        $lblRetry = "Prøv Igen";
        $lblServer = "Server";
        $lblSize = "Str.";
        $lblFileType = "Type";
        $lblTo = "Til";
        $lblTransferMode = "Overførselsmodus";
        $lblTryAgain = "Prøv Igen...";
        $lblUnziped = "unzippet";
        $lblUp = "Op";
        $lblUploadFile        = "Upload Fil";
        $lblUser = "Bruger";
        $lblVersion ="Version";
        $lblWithUser = "Med Bruger";
        $lblUnZipFile = "Unzip Fil";
        $lblZipFile = "Zip Fil";
        $lblPasive = "Passiv";
?>