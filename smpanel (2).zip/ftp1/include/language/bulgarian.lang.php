<?php
	// Bulgarian translation by : Krasimir S. Stefanov
	// Visit my webpage at http://cyberd.freeunixhost.com/
	
	// Change permissions
	$lblOwner="бюсёђтхэшъ";
	$lblGroup="У№ѓяр";
	$lblPublic="Яѓсышїэш";
	$lblRead="зхђхэх";
	$lblWrite="Яшёрэх";
	$lblExecute="Шчяњыэхэшх";

	//Front End

    $lblFileSizeTooBig = "дрщыр х я№хърыхэю уюыџь";
	$lblAnonymousAccess = "Рэюэшьхэ фюёђњя";
	$lblASCIIMode = "ASCII";
	$lblBinaryMode = "Binary";
	$lblChangeMode = "Я№хтъыўїш ьхцфѓ Binary/ASCII";
	$lblSetPermissions	= "Я№юьџэр эр я№ртрђр";
	$lblConnectToFTPServer = "бтњ№цш ёх ё FTP бњ№тњ№";
	$lblConnectedTo = "бтњ№чрэ ъњь";
	$lblCouldNotChangePermissionsFor = "Эх х тњчьюцэр я№юьџэрђр эр я№ртрђр эр";
	$lblCouldNotConnectToServer = "Эџьр т№њчър ёњё ёњ№тњ№р";
	$lblCouldNotCreate = "бњчфртрэхђю эхтњчьюцэю";
	$lblCouldNotDelete = "в№шхэхђю эхтњчьюцэю";
	$lblCouldNotRename = "Я№хшьхэѓтрэхђю эртњчьюцэю";
	$lblCouldNotUnzip ="unzip-трэхђю эртњчьюцэю";
	$lblCreated = "ёњчфрфхэ";
	$lblCreateDirectory	= "бњчфрщ Фш№хъђю№шџ";
	$lblCurrentDirectory="вхъѓљр фш№хъђю№шџ";
	$lblCurrentMode = "вхъѓљ №хцшь";
	$lblEditFile = "Edit";
	$lblDate	= "Фрђр";
	$lblDelete	= "Шчђ№шщ";
	$lblDeleted = "шчђ№шђ";
	$lblDeleteFile	= "Шчђ№шщ єрщыр";
	$lblDetails = "Фхђрщыш";
	$lblDirectory = "Фш№хъђю№шџ";
	$lblDirectoryEmpty = "Фш№хъђю№шџђр х я№рчэр";
	$lblDisclaimer = "phpWebFTP шфтр схч РСбЮЫовЭЮ ЭШЪРЪТР УРаРЭжШп. вютр х ётюсюфхэ ёюєђѓх№ ш тшх ьюцх фр ую №рчя№юёђ№рэџтрђх т эџъюш ёыѓїрш. Я№юїхђхђх яњыэшџ  GPL ышіхэч <A HREF='gpl.txt' style='font-size:7pt;'>ђѓъ</A>";
	$lblErrorDownloadingFile = "У№хјър я№ш ётрыџэхђю эр єрщыр";
	$lblFileCouldNotBeUploaded = "дрщыр эх ьюцх фр сњфх ърїхэ";
	$lblFilePermissionChanged="Я№ртрђр чр фюёђњя фю єрщыр я№юьхэхэш";
	$lblCouldNotChangePermissions ="Я№ртрђр чр фюёђњя фю єрщыр эх ьюурђ фр сњфрђ я№юьхэхэш";
	$lblFileTasks = "File and Folder Tasks";
	$lblGoToDirectory = "Шфш т Фш№хъђю№шџ";
	$lblIndexOf = "Шэфхъё эр";
	$lblLogIn ="Тыхч";
	$lblLogOff ="Шчѕюф";
	$lblName = "Шьх";
	$lblNewName = "Эютю шьх";
	$lblNotConnected = "Эх ёђх ётњ№чрэш";
	$lblNotice = "Чрсхыхцър";
	$lblPassword = "Яр№юыр";
	$lblLanguage= "Хчшъ";
	$lblPermissions = "Я№ртр";
	$lblPort = "Яю№ђ";
	$lblRename	= "Я№хшьхэѓтрщ";
	$lblRenamedTo = "я№хшьхэѓтрэ эр";
	$lblRetry = "Юяшђрщ яръ";
	$lblServer = "бњ№тњ№";
	$lblSize = "арчьх№";
	$lblFileType = "вшя";
	$lblTo = "ъњь";
	$lblTransferMode = "ахцшь эр ђ№рэёєх№р";
	$lblTryAgain = "Юяшђрщ яръ...";
	$lblUnziped = "unziped-эрђ";
	$lblUp = "Эрую№х";
	$lblUploadFile	= "Ърїш єрщы";
	$lblUser = "Яюђ№хсшђхы";
	$lblVersion ="Тх№ёшџ";
	$lblWithUser = "ё яюђ№хсшђхы";
	$lblUnZipFile = "Unzip-трщ єрщыр";
	$lblZipFile = "Zip єрщы";
?>
