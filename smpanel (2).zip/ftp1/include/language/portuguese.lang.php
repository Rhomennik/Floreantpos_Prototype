<?php
	// TraduÆo para o Portugus: Rodrigo Felicio Adriano

	// Change permissions
	$lblOwner="Dono";
	$lblGroup="Grupo";
	$lblPublic="Publico";
	$lblRead="Leitura";
	$lblWrite="Escrita";
	$lblExecute="Execução";

	//Front End

    $lblFileSizeTooBig = "Tamanho do arquivo muito grande";
	$lblAnonymousAccess = "Acesso Anonimo";
	$lblASCIIMode = "ASCII";
	$lblBinaryMode = "Binary";
	$lblChangeMode = "Trocar Binary/ASCII";
	$lblSetPermissions	= "Alterar Permissões";
	$lblConnectToFTPServer = "Conectar ao Servidor de FTP";
	$lblConnectedTo = "Conectado a";
	$lblCouldNotChangePermissionsFor = "Impossivel alterar permissões para";
	$lblCouldNotConnectToServer = "Impossivel se conectar ao servidor";
	$lblCouldNotCreate = "Impossivel criar";
	$lblCouldNotDelete = "Impossivel apagar";
	$lblCouldNotRename = "Impossivel renomear";
	$lblCouldNotUnzip ="Impossivel descompactar";
	$lblCreated = "criado";
	$lblCreateDirectory	= "Diretorio Criado";
	$lblCurrentDirectory="Diretorio atual";
	$lblCurrentMode = "Modo atual";
	$lblDate	= "Data";
	$lblEditFile = "Edit";
	$lblDelete	= "Apagado";
	$lblDeleted = "apagado";
	$lblDeleteFile	= "Arquivo apagado";
	$lblDetails = "Detalhes";
	$lblDirectory = "Diretorio";
	$lblDirectoryEmpty = "Diretorio esta vazio";
	$lblDisclaimer = "phpWebFTP comes with ABSOLUTELY NO WARRANTY. This is free software, and you are welcome to redistribute it under certain conditions. Read the full GPL license <A HREF='gpl.txt' style='font-size:7pt;'>here</A>";
	$lblErrorDownloadingFile = "Erro ao baixar arquivo";
	$lblFileCouldNotBeUploaded = "Arquivo nao pode ser enviado";
	$lblFilePermissionChanged="Permissao do arquivo alterada";
	$lblCouldNotChangePermissions ="Permissao do arquivo não pode ser alterada";
	$lblFileTasks = "Tarefas de Pastas e Arquivos";
	$lblGoToDirectory = "Ir para o diretorio";
	$lblIndexOf = "Index de";
	$lblLogIn ="Log in";
	$lblLogOff ="Log off";
	$lblName = "Nome";
	$lblNewName = "Novo name";
	$lblNotConnected = "Nao conectado";
	$lblNotice = "Noticia";
	$lblPassword = "Password";
	$lblLanguage= "Linguagem";
	$lblPermissions = "Permissoes";
	$lblPort = "Porta";
	$lblRename	= "Renomear";
	$lblRenamedTo = "renomeado para";
	$lblRetry = "Tentar novamente";
	$lblServer = "Servidor";
	$lblSize = "Tamanho";
	$lblFileType = "Tipo";
	$lblTo = "para";
	$lblTransferMode = "Modo de transferencia";
	$lblTryAgain = "Tente novamente...";
	$lblUnziped = "descompactado";
	$lblUp = "Acima";
	$lblUploadFile	= "Arquivo Enviado";
	$lblUser = "Usuario";
	$lblVersion ="Versao";
	$lblWithUser = "com usuario";
	$lblUnZipFile = "Arquivo Descompactado";
	$lblZipFile = "Arquivo Compactado";
	$lblPasive = "Passive";
?>


