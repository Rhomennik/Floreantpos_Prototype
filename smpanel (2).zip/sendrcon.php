<?php
if(!isset($_POST["ip"]) || !isset($_POST["port"]) || !isset($_POST["rcon"]) || !isset($_POST["cmd"])) exit();

require_once("inc/SourceQuery.class.php");
require_once("inc/Exceptions.class.php");
use xPaw\SourceQuery\Exception\AuthenticationException;
use xPaw\SourceQuery\Exception\SocketException;
use xPaw\SourceQuery\Exception\InvalidPacketException;


$ip     = (string)$_POST["ip"];
$port   = (int)$_POST["port"];
$rcon   = (string)$_POST["rcon"];
$cmd    = (string)$_POST["cmd"];

$result = "";
$err    = true;

$sq = new SourceQuery();
try {
    $sq->Connect($ip, $port, 25);
    $sq->SetRconPassword($rcon);
    $result = $sq->Rcon($cmd);
    $err = false;
}catch (SocketException $e){
    $result = "Error on connection: " . $e->getMessage();
}catch (InvalidPacketException $e){
    $result = "Unknown error. (". $e->getMessage() . ")";
}catch (AuthenticationException $e){
    $result = "Invalid RCON password";
}catch (\xPaw\SourceQuery\Exception\TimeoutException $e){
    $result = "Error: " . $e->getMessage();
}finally{
    $sq->Disconnect();
}


echo json_encode(
    [
        "error"  => $err,
        "result" => $result
    ]
);