-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 05 Haz 2017, 22:29:07
-- Sunucu sürümü: 5.5.55-0+deb7u1
-- PHP Sürümü: 5.6.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ni792093_5sql28`
--

-- --------------------------------------------------------

-- Drop the tables...
DROP TABLE IF EXISTS  mithat_admins;
DROP TABLE IF EXISTS  mithat_lastconnected;
DROP TABLE IF EXISTS  mithat_map;
DROP TABLE IF EXISTS  mithat_players;
DROP TABLE IF EXISTS  mithat_playerstats;
DROP TABLE IF EXISTS  mithat_reports;
DROP TABLE IF EXISTS  mithat_score;
DROP TABLE IF EXISTS  mithat_server;

--
-- Tablo için tablo yapısı `mithat_admins`
--

CREATE TABLE `mithat_admins` (
  `username` text NOT NULL,
  `password` VARCHAR(255) NOT NULL -- Not sure what the appropriate length is.
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `mithat_admins`
--

INSERT INTO `mithat_admins` (`username`, `password`) VALUES
('admin', '$2y$10$atYwTEu5eXEziZzB6QwVqOnyK.MpGE58GiWnt/jLv1/FZg5bqdAFG');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mithat_lastconnected`
--

CREATE TABLE `mithat_lastconnected` (
  `id` int(10) NOT NULL,
  `name` text NOT NULL,
  `steamid` text NOT NULL,
  `time` text NOT NULL,
  `ip` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `mithat_lastconnected`
--

INSERT INTO `mithat_lastconnected` (`id`, `name`, `steamid`, `time`, `ip`) VALUES
(1, 'Mithat', 'STEAM', '18:00', 'IP');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mithat_map`
--

CREATE TABLE `mithat_map` (
  `id` int(10) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `mithat_map`
--

INSERT INTO `mithat_map` (`id`, `name`) VALUES
(1, 'de_dust2');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mithat_players`
--

CREATE TABLE `mithat_players` (
  `id` int(10) NOT NULL,
  `count` int(10) NOT NULL,
  `ct` int(100) NOT NULL,
  `tr` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `mithat_players`
--

INSERT INTO `mithat_players` (`id`, `count`, `ct`, `tr`) VALUES
(1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mithat_playerstats`
--

CREATE TABLE `mithat_playerstats` (
  `id` int(10) NOT NULL,
  `steamid` text CHARACTER SET latin1 NOT NULL,
  `name` text CHARACTER SET latin1 NOT NULL,
  `ip` text CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mithat_reports`
--

CREATE TABLE `mithat_reports` (
  `id` int(100) NOT NULL,
  `name` text NOT NULL,
  `report` text NOT NULL,
  `steamid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `mithat_reports`
--

INSERT INTO `mithat_reports` (`id`, `name`, `report`, `steamid`) VALUES
(1, 'Mithat Guner', 'ORNEK OYUNCU SIKAYETI', 'STEAMID'),
(2, 'Mithat Guner', 'TEST', 'STEAMID');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mithat_score`
--

CREATE TABLE `mithat_score` (
  `id` int(10) NOT NULL,
  `ctscore` text NOT NULL,
  `tscore` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `mithat_score`
--

INSERT INTO `mithat_score` (`id`, `ctscore`, `tscore`) VALUES
(1, '0', '0');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mithat_server`
--

CREATE TABLE `mithat_server` (
  `id` int(10) NOT NULL,
  `servername` VARCHAR(64) NOT NULL,
  `serverip` VARCHAR(16) NOT NULL, -- 255.255.255.255 => 3.3.3.3 => 12 + 3 dots = 15
  `serverport` INT(5) NOT NULL,
  `rcon_password` VARCHAR(32) NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `mithat_server`
--

INSERT INTO `mithat_server` (`id`, `servername`, `serverip`, `serverport`) VALUES
(1, 'EXAMPLE SERVER', '127.0.0.1', '27015');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `mithat_admins`
--
ALTER TABLE `mithat_admins`
  ADD UNIQUE KEY `username` (`username`(32));

--
-- Tablo için indeksler `mithat_reports`
--
ALTER TABLE `mithat_reports`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `mithat_reports`
--
ALTER TABLE `mithat_reports`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
