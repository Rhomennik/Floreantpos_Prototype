<?php

if(!isset($_SESSION["kadi"]))
    header("Location: login.php");

include("config.php");
ob_start();
session_start();

$user = $_POST['kadi']; // Username
$pass = $_POST['sifre']; // Password

$stmt = $conn->prepare("SELECT username, password FROM mithat_admins WHERE username = ?");
$stmt->bind_param("s", $user);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($username, $password);
$stmt->fetch();

if($stmt->num_rows > 0) { // We got a username...
    if (password_verify($pass, $password)) {
        $_SESSION["login"] = "true";
        $_SESSION["user"] = $username;
        header("Location: index.php");
    }
}else{
    $_SESSION["empty"] = "wrong"; // Default it to wrong.
    header("Location: login.php");
}

// Close
$stmt->close();
$conn->close();

ob_end_flush();
?>