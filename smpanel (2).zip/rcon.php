<?php
ob_start();
session_start();

if (!isset($_SESSION["login"])) {
    header("Location:index.php");
}

require_once("config.php");

$query = $conn->query("SELECT servername, serverip, serverport, rcon_password FROM mithat_server");
$servers[] = $query->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- This file has been downloaded from Bootsnipp.com. Enjoy! -->
    <title>RCON KOMUT</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/rcon.css">
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
</head>
<body>
<!--
<noscript>
    This website requires JavaScript to be enabled.
</noscript>
-->
<div class="container auth">
    <h1 class="text-center">RCON PANEL<span>SOURCEMOD</span></h1>
    <div id="big-form" class="well auth-box">
        <div>
            <label for="svs">Server to rcon:</label>
            <select name="servers" id="svs">
                <?php foreach ($servers as $server) : ?>
                    <option value="<?= $server["serverip"] ?>:<?= $server["serverport"] ?>:<?= $server["rcon_password"] ?>">
                        <?= $server["servername"] ?>
                    </option>
                    <option value="00.<?= $server["serverip"] ?>:<?= $server["serverport"] ?>:<?= $server["rcon_password"] ?>">
                        <?= $server["servername"] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <form action="sendrcon.php" method="post">
            <fieldset>
                <!-- Form Name -->
                <legend>Rcon Panel</legend>
                Command: <input type="text" name="komut" id="cmd" placeholder="command..."><br>
                <input type="submit" id="submit">
        </form>

        </fieldset>
        <div class="clearfix"></div>
        <div>
            <pre id="result" style="display: none;"></pre>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        Made by: <a href="https://forums.alliedmods.net/member.php?u=273627">Mithat Güner</a>
    </footer>
</body>
<script type="text/javascript">
    (function (e, t, n, r) {
        function o(t, n) {
            this.$element = e(t);
            this.settings = e.extend({}, s, n);
            this.init()
        }

        var i = "floatlabel", s = {
            slideInput: true,
            labelStartTop: "20px",
            labelEndTop: "10px",
            transitionDuration: .3,
            transitionEasing: "ease-in-out",
            labelClass: "",
            typeMatches: /text|password|email|number|search|url/
        };
        o.prototype = {
            init: function () {
                var e = this;
                var n = {
                    "-webkit-transition": "all " + this.settings.transitionDuration + "s " + this.settings.transitionEasing,
                    "-moz-transition": "all " + this.settings.transitionDuration + "s " + this.settings.transitionEasing,
                    "-o-transition": "all " + this.settings.transitionDuration + "s " + this.settings.transitionEasing,
                    "-ms-transition": "all " + this.settings.transitionDuration + "s " + this.settings.transitionEasing,
                    transition: "all " + this.settings.transitionDuration + "s " + this.settings.transitionEasing
                };
                if (this.$element.prop("tagName").toUpperCase() !== "INPUT") {
                    return
                }
                if (!this.settings.typeMatches.test(this.$element.attr("type"))) {
                    return
                }
                var r = this.$element.attr("id");
                if (!r) {
                    r = Math.floor(Math.random() * 100) + 1;
                    this.$element.attr("id", r)
                }
                var i = this.$element.attr("placeholder");
                var s = this.$element.data("label");
                var o = this.$element.data("class");
                if (!o) {
                    o = ""
                }
                if (!i || i === "") {
                    i = "You forgot to add placeholder attribute!"
                }
                if (!s || s === "") {
                    s = i
                }
                this.inputPaddingTop = parseFloat(this.$element.css("padding-top")) + 10;
                this.$element.wrap('<div class="floatlabel-wrapper" style="position:relative"></div>');
                this.$element.before('<label for="' + r + '" class="label-floatlabel ' + this.settings.labelClass + " " + o + '">' + s + "</label>");
                this.$label = this.$element.prev("label");
                this.$label.css({
                    position: "absolute",
                    top: this.settings.labelStartTop,
                    left: this.$element.css("padding-left"),
                    display: "none",
                    "-moz-opacity": "0",
                    "-khtml-opacity": "0",
                    "-webkit-opacity": "0",
                    opacity: "0"
                });
                if (!this.settings.slideInput) {
                    this.$element.css({"padding-top": this.inputPaddingTop})
                }
                this.$element.on("keyup blur change", function (t) {
                    e.checkValue(t)
                });
                t.setTimeout(function () {
                    e.$label.css(n);
                    e.$element.css(n)
                }, 100);
                this.checkValue()
            }, checkValue: function (e) {
                if (e) {
                    var t = e.keyCode || e.which;
                    if (t === 9) {
                        return
                    }
                }
                var n = this.$element.data("flout");
                if (this.$element.val() !== "") {
                    this.$element.data("flout", "1")
                }
                if (this.$element.val() === "") {
                    this.$element.data("flout", "0")
                }
                if (this.$element.data("flout") === "1" && n !== "1") {
                    this.showLabel()
                }
                if (this.$element.data("flout") === "0" && n !== "0") {
                    this.hideLabel()
                }
            }, showLabel: function () {
                var e = this;
                e.$label.css({display: "block"});
                t.setTimeout(function () {
                    e.$label.css({
                        top: e.settings.labelEndTop,
                        "-moz-opacity": "1",
                        "-khtml-opacity": "1",
                        "-webkit-opacity": "1",
                        opacity: "1"
                    });
                    if (e.settings.slideInput) {
                        e.$element.css({"padding-top": e.inputPaddingTop})
                    }
                }, 50)
            }, hideLabel: function () {
                var e = this;
                e.$label.css({
                    top: e.settings.labelStartTop,
                    "-moz-opacity": "0",
                    "-khtml-opacity": "0",
                    "-webkit-opacity": "0",
                    opacity: "0"
                });
                if (e.settings.slideInput) {
                    e.$element.css({"padding-top": parseFloat(e.inputPaddingTop) - 10})
                }
                t.setTimeout(function () {
                    e.$label.css({display: "none"})
                }, e.settings.transitionDuration * 1e3)
            }
        };
        e.fn[i] = function (t) {
            return this.each(function () {
                if (!e.data(this, "plugin_" + i)) {
                    e.data(this, "plugin_" + i, new o(this, t))
                }
            })
        }
    })(jQuery, window, document);

    $(document).ready(function () {
        //Floatlabel
        $('input').floatlabel();
        var command, selected;
        var resBox = $("#result");
        var submitBtn = $("#submit");
        $('form').submit(function (e) {
            e.preventDefault();
            selected = $("#svs").val().split(":");
            command = $("#cmd").val();
            $.ajax({
                url: "sendrcon.php",
                method: "POST",
                data: {
                    ip: selected[0],
                    port: selected[1],
                    rcon: selected[2],
                    cmd: command
                },
                dataType: "json",

                beforeSend: function () {
                    submitBtn.attr("disabled", "true");
                },

                error: function (jqXHR, textStatus, errorThrown) {
                    alert("An unknown error occurred(" + errorThrown + ")");
                },

                success: function (data) {
                    if(data.error){
                        alert("Error: " + data.result);
                    }else {
                        resBox.css("display", "block");
                        resBox.text(data.result);
                    }
                },

                complete: function () {
                    submitBtn.removeAttr("disabled")
                }
            });
        });

    });
</script>
</html>

<?php
    $conn->close();
?>