<?php

$config = array();

/**
 * Database configuration.
 */
$config["db"]["host"]   = "localhost";  // Host
$config["db"]["db"]     = "smpanel";    // Database
$config["db"]["user"]   = "root";       // User
$config["db"]["pass"]   = "";           // Password
$config["db"]["charset"]= "latin5";     // Charset


// Do not touch!! Only modify if You know what You're doing!
$ftpHost = "";
$ftpPort = "21";
$ftpMode = "1";
$ftpSSL  = "0";
$ftpDir  = "";
$serverTmp = "";
$editableExts = "asp,ashx,asmx,aspx,asx,axd,cfm,cgi,css,html,htm,jhtml,js,php,phtml,pl,txt,xhtml";
$sessionName = "";
$dateFormatUsa = 0;
$lockOutTime = 5;
$versionCheck = 1;
$showAdvOption = 1;
$showLockSess = 1;
$showHostInfo = 1;
$showAddons = 1;
$showDotFiles = 1;
$maxExecTime = 1800;
$maxFileSize = "1024M";

$conn = new mysqli(
    $config["db"]["host"],
    $config["db"]["user"],
    $config["db"]["pass"],
    $config["db"]["db"]
    ) or die("Couldn't establish a connection to the host."); // Welp, can't make it happen

$conn->set_charset($config["db"]["charset"]);

?>