<?php
// This is used to override values in defaults.php at main level.

$mydbr_defaults['page_title'] = 'myDBR Own';

/* 
  Debug flag to determine server cookie problems. 
  Enabling this may expose your database login information so use with caution

  $mydbr_defaults['debug_cookie'] = true;
*/
